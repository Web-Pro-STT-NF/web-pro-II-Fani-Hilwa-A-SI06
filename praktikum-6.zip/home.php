<?php
include_once "form_pasien.php";
include_once "class_BMIpasien.php";
include_once "class_BMI.php";
?>